package sibusisopart1;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class QuickChat {
    
    // Instance variables for each message
    private String messageID;
    private int messageNumber;
    private String recipient;
    private String message;
    private String messageHash;
    private String messageStatus;
    
    // Collections to store messages
    private static ArrayList<QuickChat> sentMessages = new ArrayList<>();
    private static ArrayList<QuickChat> storedMessages = new ArrayList<>(); //[cite: 8]
    private static final String JSON_FILE = "messages.json"; //[cite: 8]
    
    // Constructor
    public QuickChat(String messageID, int messageNumber, String recipient, String message) {
        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.message = message;
        this.messageHash = createMessageHash();
    }
    
    // 1. Ensures message ID is not more than ten characters
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }
    
    // 2. Ensures recipient cell number is valid and starts with '+'
    public String checkRecipientCell() {
        if (recipient != null && recipient.startsWith("+") && recipient.length() <= 12) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an international code.";
    }
    
    // 3. Creates and returns the Message Hash
    public String createMessageHash() {
        if (messageID == null || messageID.length() < 2 || message == null || message.trim().isEmpty()) {
            return "00:0:INVALID";
        }
        String prefix = messageID.substring(0, 2);
        
        String trimmedMsg = message.trim().replaceAll("[^a-zA-Z0-9\\s]", "");
        String[] words = trimmedMsg.split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 0 ? words[words.length - 1] : "";
        
        return (prefix + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
    }
    
    // 4. Allows user to choose if they want to send, store, or disregard the message
    public String SentMessage(int choice) {
        switch (choice) {
            case 1:
                this.messageStatus = "Sent";
                sentMessages.add(this);
                return "Message successfully sent.";
            case 2:
                this.messageStatus = "Disregarded";
                return "Press 0 to delete the message.";
            case 3:
                this.messageStatus = "Stored";
                storeMessage(); //[cite: 8]
                return "Message successfully stored.";
            default:
                this.messageStatus = "Unknown";
                return "Invalid choice";
        }
    }
    
    // PRINT MESSAGES: all messages sent while the program is running[cite: 9]
    public static String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages have been sent.";
        }
        
        String all = "";
        for (QuickChat sent : sentMessages) {
            all = all + sent.getMessageDetails() + "\n";
        }
        return all;
    }

    // Helper method to return details as a formatted string
    public String getMessageDetails() {
        return "\n-----------------------------\n" +
               "Message ID: " + messageID + "\n" +
               "Message Hash: " + messageHash + "\n" +
               "Recipient: " + recipient + "\n" +
               "Message: " + message + "\n" +
               "-----------------------------";
    }

    // STORE MESSAGE: adds this message to the stored list and writes every stored message to messages.json[cite: 8]
    public boolean storeMessage() {
        storedMessages.add(this);

        StringBuilder json = new StringBuilder("\n");
        json.append("[\n");

        for (int i = 0; i < storedMessages.size(); i++) {
            QuickChat m = storedMessages.get(i);

            json.append("  {\n");
            json.append("    \"messageID\": \"").append(escapeJson(m.messageID)).append("\",\n");
            json.append("    \"messageNumber\": ").append(m.messageNumber).append(",\n");
            json.append("    \"messageHash\": \"").append(escapeJson(m.messageHash)).append("\",\n");
            json.append("    \"recipient\": \"").append(escapeJson(m.recipient)).append("\",\n");
            json.append("    \"message\": \"").append(escapeJson(m.message)).append("\"\n");
            json.append("  }");

            if (i < storedMessages.size() - 1) {
                json.append(",");
            }
            json.append("\n");
        }

        json.append("]");

        try (FileWriter writer = new FileWriter(JSON_FILE)) {
            writer.write(json.toString());
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    // Makes text safe to place inside a JSON string[cite: 7]
    private static String escapeJson(String text) {
        if (text == null) {
            return "";
        }
        return text.replace("\\", "\\\\")
                   .replace("\"", "\\\"")
                   .replace("\n", "\\n")
                   .replace("\r", "\\r")
                   .replace("\t", "\\t");
    }

    // 5. Returns the total number of messages sent[cite: 9]
    public static int returnTotalMessages() {
        return sentMessages.size();
    }
    
    // 6. Helper method to generate a random 10-digit ID
    public static String generateMessageID() {
        Random rand = new Random();
        long id = 1000000000L + (long)(rand.nextDouble() * 9000000000L);
        return String.valueOf(id);
    }
    
    // 7. Displays full message details
    public static void printMessageDetails(QuickChat m) {
        System.out.println(m.getMessageDetails());
    }

    // Getters
    public String getMessageID() { return messageID; }
    public int getMessageNumber() { return messageNumber; }
    public String getRecipient() { return recipient; }
    public String getMessage() { return message; }
    public String getMessageHash() { return messageHash; }
    public String getMessageStatus() { return messageStatus; }
}