package sibusisopart1;

import org.junit.Test;
import static org.junit.Assert.*;

public class QuickChatTest {

    // --- 1. Test Username Validation ---
    @Test
    public void testCheckUserName() {
        assertTrue(
            "Valid username should contain an underscore and be 5 characters or less",
            SibusisoPart1.checkUserName("sib_1")
        );

        assertFalse(
            "Username without an underscore should be invalid",
            SibusisoPart1.checkUserName("sibusiso")
        );

        assertFalse(
            "Username longer than 5 characters should be invalid",
            SibusisoPart1.checkUserName("sib_123")
        );
    }

    // --- 2. Test Password Validation ---
    @Test
    public void testCheckPassword() {
        assertTrue(
            "Valid password should contain 8+ characters, capital letter, number and special character",
            SibusisoPart1.checkPassword("Password1!")
        );

        assertFalse(
            "Password without a capital letter should be invalid",
            SibusisoPart1.checkPassword("password1!")
        );

        assertFalse(
            "Password without a number should be invalid",
            SibusisoPart1.checkPassword("Password!")
        );

        assertFalse(
            "Password without a special character should be invalid",
            SibusisoPart1.checkPassword("Password1")
        );

        assertFalse(
            "Password shorter than 8 characters should be invalid",
            SibusisoPart1.checkPassword("Pass1!")
        );
    }

    // --- 3. Test Cell Phone Number Validation ---
    @Test
    public void testCheckCellPhoneNumber() {
        assertTrue(
            "Phone number with international code should be valid",
            SibusisoPart1.checkCellPhoneNumber("+27821234567")
        );

        assertFalse(
            "Phone number without international code should be invalid",
            SibusisoPart1.checkCellPhoneNumber("0821234567")
        );

        assertFalse(
            "Phone number longer than 13 characters should be invalid",
            SibusisoPart1.checkCellPhoneNumber("+27821234567890")
        );
    }

    // --- 4. Test QuickChat Message ID Length Check ---
    @Test
    public void testCheckMessageID() {
        QuickChat validChat = new QuickChat("1234567890", 0, "+27821234567", "Hello");
        assertTrue("Message ID of 10 characters or less should be valid", validChat.checkMessageID());

        QuickChat invalidChat = new QuickChat("1234567890123", 0, "+27821234567", "Hello");
        assertFalse("Message ID longer than 10 characters should be invalid", invalidChat.checkMessageID());
    }

    // --- 5. Test Recipient Cell Number Check ---
    @Test
    public void testCheckRecipientCell() {
        QuickChat validChat = new QuickChat("1234567890", 0, "+27821234567", "Hello");
        assertEquals("Cell phone number successfully captured.", validChat.checkRecipientCell());

        QuickChat invalidChat = new QuickChat("1234567890", 0, "0821234567", "Hello");
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code.", invalidChat.checkRecipientCell());
    }

    // --- 6. Test Message Hash Generation ---
    @Test
    public void testCreateMessageHash() {
        QuickChat chat = new QuickChat("1234567890", 0, "+27821234567", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("12:0:HITONIGHT", chat.createMessageHash());
    }

    // --- 7. Test Message Options (Sent, Disregarded, Stored) ---
    @Test
    public void testSentMessageOptions() {
        QuickChat chat = new QuickChat("1234567890", 0, "+27821234567", "Test message");

        assertEquals("Message successfully sent.", chat.SentMessage(1));
        assertEquals("Press 0 to delete the message.", chat.SentMessage(2));
        assertEquals("Message successfully stored.", chat.SentMessage(3));
        assertEquals("Invalid choice", chat.SentMessage(99));
    }

    // --- 8. Test Total Messages Counter ---
    @Test
    public void testReturnTotalMessages() {
        int initialCount = QuickChat.returnTotalMessages();
        QuickChat chat = new QuickChat("1234567890", 0, "+27821234567", "Test message");
        chat.SentMessage(1); // Sends and adds to sent collection
        assertEquals(initialCount + 1, QuickChat.returnTotalMessages());
    }

    // --- 9. Test Login Status Messages ---
    @Test
    public void testReturnLoginStatus() {
        SibusisoPart1 user = new SibusisoPart1();
        user.name = "Sibusiso";
        user.surname = "Mkhize";

        String successMsg = login.returnLoginStatus(user, true);
        assertEquals("Welcome Sibusiso, Mkhize To QuickChat.", successMsg);

        String failureMsg = login.returnLoginStatus(user, false);
        assertEquals("Username or password is incorrect, please try again.", failureMsg);
    }
}